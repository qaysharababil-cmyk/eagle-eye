# Device location tracker (GitHub Pages + Supabase)

- `index.html`: dashboard with a map of every device's latest position (sign-in required)
- `track.html`: page each device opens to share its location (sign-in, explicit Start/Stop)
- `schema.sql`: database tables and access rules
- `config.js`: your Supabase URL and anon key

## Setup

1. **Supabase:** create a free project at supabase.com.
2. **Database:** open SQL Editor, paste `schema.sql`, and run it.
3. **Accounts:** go to Authentication > Users and add one user per device, plus one for yourself. In Authentication settings, turn off "Allow new users to sign up" so strangers cannot create accounts.
4. **Make yourself a viewer:** run this in the SQL Editor (use your email):
   ```sql
   insert into viewers (user_id) select id from auth.users where email = 'you@example.com';
   ```
5. **Config:** copy the Project URL and the `anon` public key into `config.js`.
6. **GitHub Pages:** push these files to a repo, then Settings > Pages > Deploy from branch (`main`, root). Your site will be at `https://USERNAME.github.io/REPO/`.
7. **Each device:** open `.../track.html`, sign in with that device's account, enter a name, tap **Start sharing**, and allow location access.

## Find by phone number

A website cannot find a phone from its number alone. Only the phone itself, or the phone carrier, knows where it is. So this works with the person's consent:

1. Run `schema-invites.sql` in the SQL Editor (after `schema.sql`).
2. On `index.html`, type the number with country code and tap **Create link**.
3. Send the link with the **WhatsApp** or **SMS** button.
4. The person opens `share.html`, taps **Share my location**, and allows the browser prompt.
5. Their position appears on your map and updates while their page stays open. They can stop at any time, and you can remove the entry.

Links expire after 7 days, and a link can only send a location. It cannot read anything.

## Limits to know

- Browsers only send location while `track.html` is open (and on iPhone, usually while the screen is on). For true background tracking, use an app such as OwnTracks or Traccar instead and keep this dashboard for viewing.
- Location needs HTTPS. GitHub Pages provides it.
- Data is stored in your Supabase project. Delete old rows regularly (see the last line of `schema.sql`).
- Only track devices whose owners know about it and agreed.
