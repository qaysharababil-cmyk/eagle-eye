-- Run this AFTER schema.sql (Supabase > SQL Editor).
-- Adds "enter a phone number, send a link, see their location".
-- The person must open the link and tap Share themselves.

create table invites (
  token text primary key default replace(gen_random_uuid()::text, '-', ''),
  owner uuid not null default auth.uid() references auth.users(id) on delete cascade,
  phone text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '7 days',
  revoked boolean not null default false,
  lat double precision,
  lng double precision,
  accuracy real,
  updated_at timestamptz
);

alter table invites enable row level security;

-- Only viewers can create and read their own invites.
create policy "viewer manages own invites" on invites
  for all to authenticated
  using (owner = auth.uid())
  with check (
    owner = auth.uid()
    and exists (select 1 from viewers v where v.user_id = auth.uid())
  );

-- The invited person has no account. They can only call these two functions,
-- and only with the secret token from their link.
create function submit_shared_location(
  p_token text, p_lat double precision, p_lng double precision, p_accuracy real
) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if p_lat not between -90 and 90 or p_lng not between -180 and 180 then
    return false;
  end if;
  update invites
     set lat = p_lat, lng = p_lng, accuracy = p_accuracy, updated_at = now()
   where token = p_token and not revoked and expires_at > now();
  return found;
end $$;

create function end_shared_location(p_token text) returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update invites set revoked = true, lat = null, lng = null
   where token = p_token;
  return found;
end $$;

revoke all on function submit_shared_location(text, double precision, double precision, real) from public;
revoke all on function end_shared_location(text) from public;
grant execute on function submit_shared_location(text, double precision, double precision, real) to anon, authenticated;
grant execute on function end_shared_location(text) to anon, authenticated;
