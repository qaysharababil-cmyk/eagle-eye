// Paste your Supabase project values here (Project Settings > API).
// The anon key is meant to be public. Your data is protected by the
// Row Level Security rules in schema.sql, NOT by hiding this key.
// Never put the "service_role" key in this file.
const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
const SUPABASE_ANON_KEY = "YOUR-ANON-KEY";
