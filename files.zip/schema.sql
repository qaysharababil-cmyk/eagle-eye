-- Run this once in Supabase: SQL Editor > New query > paste > Run

create table locations (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  device_name text not null,
  lat double precision not null,
  lng double precision not null,
  accuracy real,
  recorded_at timestamptz not null default now()
);
create index on locations (user_id, recorded_at desc);

-- People who are allowed to see ALL devices on the dashboard.
create table viewers (
  user_id uuid primary key references auth.users(id) on delete cascade
);

alter table locations enable row level security;
alter table viewers enable row level security;

-- A device account can only add rows for itself.
create policy "device inserts own rows" on locations
  for insert to authenticated
  with check (user_id = auth.uid());

-- A device can see its own rows. Viewers can see every device.
create policy "read own or as viewer" on locations
  for select to authenticated
  using (
    user_id = auth.uid()
    or exists (select 1 from viewers v where v.user_id = auth.uid())
  );

-- A user can check whether they are a viewer.
create policy "see own viewer row" on viewers
  for select to authenticated
  using (user_id = auth.uid());

-- Newest position per device (respects the policies above).
create view latest_locations with (security_invoker = true) as
  select distinct on (user_id)
    user_id, device_name, lat, lng, accuracy, recorded_at
  from locations
  order by user_id, recorded_at desc;

-- AFTER you create your own account (Authentication > Users),
-- make yourself a viewer. Replace the email:
-- insert into viewers (user_id)
--   select id from auth.users where email = 'you@example.com';

-- Optional: delete data older than 30 days (run manually or schedule it).
-- delete from locations where recorded_at < now() - interval '30 days';
